function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  if(mouseIsPressed){
      fill('red')
  }
  circle(200,200,100)
}